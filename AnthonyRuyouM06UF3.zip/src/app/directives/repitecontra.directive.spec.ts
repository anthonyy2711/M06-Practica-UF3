import { RepitecontraDirective } from './repitecontra.directive';

describe('RepitecontraDirective', () => {
  it('should create an instance', () => {
    const directive = new RepitecontraDirective();
    expect(directive).toBeTruthy();
  });
});
