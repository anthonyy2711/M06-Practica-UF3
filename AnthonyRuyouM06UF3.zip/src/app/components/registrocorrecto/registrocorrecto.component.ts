import { Component } from '@angular/core';

@Component({
  selector: 'app-registrocorrecto',
  templateUrl: './registrocorrecto.component.html',
  styleUrls: ['./registrocorrecto.component.css']
})
export class RegistrocorrectoComponent {

}
